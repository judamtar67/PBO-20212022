package binatang;
public interface IHerbivora {
    public abstract void displayMakan();
}
