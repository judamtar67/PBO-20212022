package binatang;
public interface IKarnivora {
    public abstract void displayMakan();
}
