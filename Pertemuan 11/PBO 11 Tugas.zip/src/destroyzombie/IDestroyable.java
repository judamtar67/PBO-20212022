package destroyzombie;
public interface IDestroyable {
    public abstract void destroyed();
}
