package overriding;
public class Dosen10 extends Manusia10{
    public void makan(){
        System.out.println("Dosen sedang Makan.");
    }
    public void lembur(){
        System.out.println("Dosen Bekerja Lembur.");
    }
}
