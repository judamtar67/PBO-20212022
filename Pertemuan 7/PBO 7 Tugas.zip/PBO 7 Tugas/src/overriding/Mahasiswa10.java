package overriding;
public class Mahasiswa10 extends Manusia10{
    public void makan(){
        System.out.println("Mahasiswa Sedang Makan.");
    }
    public void tidur(){
        System.out.println("Mahasiswa Sedang Tidur.");
    }
}
