package overriding;
public class Manusia10 {
    public void bernafas(){
        System.out.println("Sedang Bernafas.");
    }
    public void makan(){
        System.out.println("Sedang Makan.");
    }
}
